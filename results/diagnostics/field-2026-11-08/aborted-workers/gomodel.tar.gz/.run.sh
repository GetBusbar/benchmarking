export BENCH_RIG_ORIGIN=''
export BENCH_HARDWARE=AWS\ m7g.4xlarge\ \(Graviton3\,\ 16\ cores\ /\ 64\ GB\).\ Gateway-under-test\ pinned\ to\ 4\ cores\ \(the\ comparable\ basis\)\;\ mock\ and\ load\ generator\ on\ 6\ cores\ each\ so\ the\ mock\ never\ bottlenecks\ the\ streaming\ sweep.\ Ubuntu\ 24.04.\ One\ dedicated\ box\ per\ gateway. BENCH_ARCH=arm64
export BENCH_ENGINE_COMMIT=0954789764947f1f51f9af86687f88499b9a9d77 BENCH_ENGINE_DIRTY=0
export OTB_QUALIFY_BASELINE=94065
export SUITES=''
export OTB_DIALECTS='' OTB_MIN_CONC='' OTB_MAX_CONC=''
gw=gomodel
# Every relative path below is relative to the repo, so anchor it rather than inheriting a cwd from
# the login shell that starts this script.
cd ~/benchmarking || exit 1
# Same flapping-sudo wrapper the provision block defines, redefined here because this heredoc is a
# SEPARATE script with its own shell - a `sudoq` inherited by name would be an undefined command,
# and the two calls below are `|| true`, so it would have failed SILENTLY and left the ephemeral
# port range at its default. That range is where `run::host_connection_ceiling` gets its number, so
# a silent miss there does not break the run, it quietly changes the ceiling every sweep is read
# against. See the provision block for why one attempt is not enough.
sudoq() {
  local i
  for i in 1 2 3 4 5 6 7 8; do
    sudo -n "$@" && return 0
    sleep 2
  done
  echo "RIG: sudo -n $1 failed 8 times over ~16s (passwordless sudo is flapping on this box)" >&2
  return 1
}
# THE MEASURING INSTRUMENT NEEDS AS MANY SOCKETS AS THE THING IT MEASURES.
#
# The load generator opens ONE connection per unit of concurrency, so a sweep to c=4096 needs 4096
# file descriptors in THIS process. Ubuntu's default soft limit is 1024, and the hard limit is
# 1048576 - so the cap is ours to lift and costs nothing.
#
# Left unlifted this is not a slow measurement, it is a WRONG one: every connection past ~1020 fails
# instantly with EMFILE, the generator counts those as failed requests, and the failure is
# attributed to the gateway. A whole field run showed all ten gateways clean at c=512 and failing at
# exactly c=1024 - ten unrelated projects in Go, Rust, Python and Lua do not share a ceiling, and
# that number is the default this line raises. Every sustained@20ms figure in that run was our own
# fd limit wearing the gateway's name.
#
# The unfairness was the sharpest part: the docker daemon config above already grants CONTAINERS
# 1048576, so the gateways under test had a thousand times the sockets of the harness measuring them.
# This restores what perf/run.sh used to do for the native side before it was retired in the Rust
# rewrite (commit d7fc1f4), which removed the raise and left the comment describing it.
ulimit -n 1048576 2>/dev/null || ulimit -n "$(ulimit -Hn)" 2>/dev/null || true
echo "[rig] loadgen/mock fd limit: $(ulimit -Sn) (hard $(ulimit -Hn))"

# EPHEMERAL PORTS ARE THE REAL CONCURRENCY CEILING, so widen them deliberately rather than inherit
# a default nobody chose.
#
# A TCP connection needs a unique (src ip, src port, dst ip, dst port). Every load window drives ONE
# destination, so simultaneous connections cannot exceed this host's ephemeral source ports. Stock
# Linux gives 32768-60999, about 28,000 - below what a fast gateway can be driven to, and the moment
# it is reached `connect` returns EADDRNOTAVAIL, which the generator used to count as the gateway
# refusing. Raising fd limits alone never helped: descriptors were never the binding constraint.
#
# 16384 as the floor because every port this rig binds is below it (mock 8000; gateways 3000, 8080,
# 8101, 8102, 8787, 9080, 12000; plano's envoy internals up to 12001) - an ephemeral range reaching
# down into those could steal a port before the service binds it, which would look like a gateway
# that failed to start. The engine derives its search ceiling from whatever this ends up being
# (`run::host_connection_ceiling`), so this is the only place the number is decided.
#
# tcp_tw_reuse because a closed connection holds its port through TIME_WAIT: without recycling, a
# window that cycles connections exhausts the range well below its size. This is the safe direction
# of that knob - it permits reuse for OUTBOUND connections only.
sudoq sysctl -w net.ipv4.ip_local_port_range="16384 65535" >/dev/null 2>&1 || true
sudoq sysctl -w net.ipv4.tcp_tw_reuse=1 >/dev/null 2>&1 || true
echo "[rig] ephemeral ports: $(cat /proc/sys/net/ipv4/ip_local_port_range 2>/dev/null || echo unknown) (tw_reuse=$(cat /proc/sys/net/ipv4/tcp_tw_reuse 2>/dev/null || echo unknown))"
# The checkout is sparse (gateways + lib only), so results/ does not exist here and the snapshot
# writer does not create its own output directory - it reports an error and writes nothing.
mkdir -p results/snapshots
source ~/.cargo/env 2>/dev/null || true
export CORES=0-3 LOADCORES=4-9 MOCKCORES=10-15
export CAP_MIB=24000
sudo -n true 2>/dev/null && sudo chmod 666 /var/run/docker.sock || true
# PULL THE RIG. Nothing is built here.
#
# The engine, the mock and the load generator are all prebuilt by CI for this arch and published to
# the rolling rig release, so a bench box is a bare OS plus docker. That is what makes every box
# identical, and it is why the box installs no toolchain: a build on the box is a difference between
# boxes, and every difference between boxes is a difference in the numbers.
#
# The only thing that ever builds here is a gateway with no official artifact for this arch, and
# that is a matter for the gateway itself, done before the memory baseline is taken.
export RIG_URL="file://$PWD/rig" RIG_API="file://$PWD/rig/release.json"
source lib/rig.sh
fetch_rig "$PWD" || { echo rig fetch FAILED; echo 126 > .run-done; exit 0; }
# Record which mock this run used. rig is a moving tag, so the same URL can serve different binaries
# over time; rig.sh has just fetched it and can hash it, and the engine cannot work that out for itself,
# so hand it over the same way the commit is handed over. Empty stays empty: the engine publishes an
# absent block rather than inventing one.
export OTB_RIG_MOCK_ORIGIN="$RIG_MOCK_ORIGIN"
export OTB_RIG_MOCK_SHA256="$(_rig_sha256 "$MOCK")"
export OTB_RIG_MOCK_UPDATED_AT="$(_rig_asset_updated_at "mock-$BENCH_ARCH")"
export OTB_RIG_URL="${BENCH_RIG_ORIGIN:-$RIG_URL}"
# rig.sh puts what it fetches in bin/; the run invokes ./otb. RIG_URL comes from rig.sh, so the
# engine is fetched from the same release the rest of the rig came from, named once.
#
# Use BENCH_ARCH, not ARCH: ARCH belongs to the orchestrator and is not exported to the box, so it
# would be unset here and the URL would end in "otb-" (404).
curl -fsSL -o ./otb "$RIG_URL/otb-$BENCH_ARCH" && chmod +x ./otb
if [ ! -x ./otb ]; then
  echo "engine binary not fetched: otb-$BENCH_ARCH missing from the rig release"
  echo 126 > .run-done
  exit 0
fi
# THE LABEL MUST BE WHAT WAS PULLED, AND THE BINARY IS ASKED RATHER THAN TRUSTED.
#
# This box DOWNLOADS the engine from the rolling `rig` release; it does not build it. The commit that
# lands in every artifact came from BENCH_ENGINE_COMMIT, which the orchestrator set from its OWN
# checkout - so the stamp recorded what the operator intended to run, and nothing compared it to the
# binary that ran.
#
# 2026-08-03: a snapshot was stamped 0ce7a907 and measured by an engine containing no line of it. The
# fixes were pushed to a branch, bench-rig.yml only rebuilds the release on a push to `main`, and every
# box fetched the previous artifact. Grepping the binary on the box for two strings that exist only in
# the newer commit found neither. A whole validation run measured the wrong engine and said otherwise.
#
# The binary now carries the commit it was built from, so the two can be compared. A mismatch is fatal:
# a run that cannot prove which engine it used cannot produce a comparable measurement, and publishing
# one anyway is how a board ends up mixing instruments while every row claims the same stamp.
_otb_built_from="$(./otb engine-commit 2>/dev/null | tr -d '[:space:]')"
if [ -z "$_otb_built_from" ]; then
  echo "ENGINE STAMP UNVERIFIABLE: the fetched otb reports no build commit."
  echo "  It predates the baked-in stamp, so which engine this box would measure on cannot be"
  echo "  established. Rebuild the rig release (bench-rig.yml) from the commit you intend to run."
  echo 126 > .run-done
  exit 0
fi
if [ -n "$BENCH_ENGINE_COMMIT" ] && [ "$_otb_built_from" != "$BENCH_ENGINE_COMMIT" ]; then
  echo "ENGINE MISMATCH - refusing to measure."
  echo "  the run would stamp : $BENCH_ENGINE_COMMIT"
  echo "  the binary is from  : $_otb_built_from"
  echo "  The rig release has not been rebuilt from the commit this run pins. bench-rig.yml rebuilds"
  echo "  it on a push to main touching engine/** or mock/**, or on workflow_dispatch."
  echo 126 > .run-done
  exit 0
fi
echo "[rig] engine verified: otb built from ${_otb_built_from} matches the commit this run stamps"
# AND THE STAMP IS THE BINARY'S OWN ANSWER FROM HERE ON. The two are equal by the check above, so
# this changes nothing today - it changes what happens the day they diverge again. Deriving the
# published commit from the artifact means the stamp cannot outlive the check that verified it.
BENCH_ENGINE_COMMIT="$_otb_built_from"
export BENCH_ENGINE_COMMIT
# THE MOCK RUNS PINNED, IN ITS OWN PROCESS, on its own cores. The three-way split - gateway 0-3,
# load generator 4-9, mock 10-15 - IS the comparability basis of every published number, so a mock
# sharing cores with either of the others measures a different machine.
pkill -f "bin/mock-$BENCH_ARCH" 2>/dev/null; sleep 1
# The mock answers all six dialects by path, so a gateway that forwards the client's ingress request
# VERBATIM still gets a plausible 200 back and would be scored as having a translation it does not
# have. Recording is what makes that detectable: the mock keeps, per dialect, whether the body it
# actually received matched that dialect's request shape, and the runner reads it off /__mock/state.
# Without this the reverification is dead code and every capability verdict is a status-code guess.
#
# RECORDING IS NOT TURNED ON HERE. The mock boots quiet and the engine turns recording on around its
# one re-verification request per cell, then off again (POST /__mock/record). That is deliberate:
# this mock's own throughput is the reference every gateway's number is judged against, and a result
# within 10% of it is SUPPRESSED as mock-bound. A recorded request takes a process-wide lock, so
# leaving recording on for the millions of requests in the throughput and memory windows would slow
# the reference instrument and quietly convert real gateway measurements into suppressed ones. The
# mock is also the least-touched, most-trusted code in the harness; it stays in exactly the state
# every previously published number was taken against, and pays the recording cost once per cell.
setsid taskset -c $MOCKCORES ./bin/mock-$BENCH_ARCH --port 8000 </dev/null >mock.log 2>&1 &
# Give it a moment to bind, then refuse to measure anything if it did not: every not-served verdict
# is conditioned on the mock being up, so a run against a dead mock publishes rig failures as
# gateway capability denials. (Any HTTP answer counts as bound; the loop used to fall through to
# the measurement either way.)
_mock_up=0
for i in $(seq 1 30); do
  curl -s -m2 -o /dev/null -X POST 127.0.0.1:8000/v1/chat/completions \
    -H "content-type: application/json" -d "{}" && { _mock_up=1; break; }
  sleep 1
done
if [ "$_mock_up" != 1 ]; then
  echo "RIG FAILURE: the mock never answered on 127.0.0.1:8000 within 30s - refusing to measure (mock.log follows)"
  tail -20 mock.log 2>/dev/null
  echo 125 > .run-done
  exit 0
fi
# Refuse the run outright if the setup is wrong, rather than discovering it as a gateway that will
# not boot after the box-hours are already spent.
./otb validate "gateways/$gw" || { echo 127 > .run-done; exit 0; }
OTB_GW_CORES=$CORES LOADCORES=$LOADCORES \
  ./otb run "gateways/$gw" 127.0.0.1:8000 results/snapshots
echo $? > .run-done

# A FINISHED BOX MUST NOT BE DESTROYED BY A TIMER SIZED FOR THE WORK.
#
# The boot-time backstop is `shutdown -h +BENCH_MAX_MIN`, sized for the work. That is right for a
# wedged box and wrong for a finished one: a gateway that uses most of its budget crosses the line
# with almost no margin left, and the root volume is
# DeleteOnTermination=true, so when the timer fires AWS deletes the disk carrying results nobody pulled.
#
# That is not hypothetical. On 2026-07-29 four gateways completed full 36-cell runs and sat unharvested
# because the orchestrator process had stopped; they were found by hand. Had they not been, the timer
# would have destroyed all four finished runs.
#
# So the moment the work is done, the deadline stops being about the work and starts being about the
# harvest: cancel the boot timer and re-arm a bounded window. Cost stays capped either way, and a dead
# orchestrator now has a known amount of time to come back (see `run-on-ec2.sh harvest`) instead of
# racing whatever happened to be left of the work budget.
# A new `shutdown -h +N` REPLACES the pending one, so the boot timer is never cancelled first: if the
# re-arm fails, the boot-time backstop is still armed and the box still self-terminates.
if sudoq shutdown -h +120 2>/dev/null; then
  echo "[box] run finished; results held for 120 min for harvest, then self-terminate"
else
  echo "[box] WARNING: could not re-arm the harvest timer; the boot-time backstop (BENCH_MAX_MIN) is still the box's shutdown"
fi
